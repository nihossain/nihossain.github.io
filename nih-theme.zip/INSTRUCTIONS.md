# Deploying this theme with Claude Code

This package is the full source of the **NIH / gather.do-inspired** personal site theme: a static Jekyll site with a fixed sidebar app shell, dark-mode-default theming, and five pages (About, Work, Resume, Visuals, Contact). It's the actual source behind [nihossain.com](https://nihossain.com) — everything here is real, working code, not a stripped-down demo.

You don't need to know Jekyll to deploy this. Hand this file and the unzipped folder to Claude Code and it can do the whole thing.

## What's in this zip

```
_config.yml            site metadata + Jekyll settings
_layouts/default.html  shared shell: <head>, sidebar, nav, footer, theme toggle, favicon links
assets/css/style.css   single stylesheet — all layout/theme/color styling
index.html              About page
work.html               Work page
resume.html             Resume page
visuals.html            Visuals page
contact.html            Contact page
CNAME                   custom domain pin (currently nihossain.com — change or delete this)
favicon.ico / *.png     "NIH" monogram favicon — you'll want to swap this
apple-touch-icon.png    iOS home-screen icon
README.md               explains the design system and how the site is built
```

## Step-by-step (tell Claude Code to do this)

1. **Create your GitHub Pages repo.** It must be named exactly `<your-github-username>.github.io` for GitHub Pages to serve it at the root domain. Create it empty (no README/gitignore) on GitHub, then clone it locally.

2. **Copy this theme in.** Unzip this package's contents into the freshly cloned repo (everything except this `INSTRUCTIONS.md` file itself — delete that once you're done reading it, or leave it, Jekyll will ignore it either way since it's excluded in `_config.yml`... note: add `INSTRUCTIONS.md` to the `exclude:` list in `_config.yml` if you keep it, so Jekyll doesn't try to publish it).

3. **Personalize the content.** Ask Claude Code to go through each page and replace:
   - `_config.yml` — `title`, `description`, `author`, `email`, `url`
   - `index.html` — bio text, the three "pillar" focus areas and their icons
   - `work.html` — your own project entries
   - `resume.html` — your experience/education/skills/patents timeline
   - `visuals.html` — your own photo/video work (or delete the page and its nav link in `_layouts/default.html` if not needed)
   - `contact.html` — your email, phone, social links
   - `_layouts/default.html` footer — the same social links (LinkedIn/Instagram/Facebook/email icons) appear here too; update the `href`s
   - `favicon.ico`, `favicon-16x16.png`, `favicon-32x32.png`, `apple-touch-icon.png` — regenerate with your own initials/monogram (Claude Code can do this with Python + Pillow, the same way this set was made — see `README.md`'s favicon note)

4. **Custom domain (optional).** If you have your own domain:
   - Put it in the `CNAME` file (replacing `nihossain.com`), or delete the `CNAME` file entirely to just use `<username>.github.io`
   - At your DNS provider, point the domain at GitHub Pages:
     - Apex/root `A` records → `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
     - `www` `CNAME` → `<username>.github.io.`
   - GitHub auto-issues an HTTPS certificate once it detects correct DNS (can take minutes to about an hour)
   - Note: once a `CNAME` file exists, GitHub Pages will always redirect `<username>.github.io` → your custom domain. That's expected, not a bug.

5. **Push.** `git add -A && git commit -m "Personalize site" && git push origin main`. GitHub Pages rebuilds automatically — no CI config needed.

6. **Verify.** Load the site, check both light and dark mode (toggle is in the sidebar), and check it on a phone — the nav row collapses to a horizontal wrapping layout under 860px width.

## Design notes for Claude Code

- All theming is CSS custom properties in `assets/css/style.css` (`:root` for light, `html[data-theme="dark"]` for dark) — change the palette there, not per-element.
- The site defaults to dark mode (`data-theme="dark"` on `<html>` in `_layouts/default.html`); a visitor's toggle choice is saved to `localStorage` and overrides the default on return visits.
- Every page is just Jekyll front matter (`title`, `description`) + a content fragment — the sidebar/nav/footer live once in `_layouts/default.html` and don't need repeating.
- No JS framework, no build step beyond Jekyll itself (which GitHub Pages runs for you on every push).
